// Generated from the complete vendored source receipt by import-localfold.mjs.
export const LOCALFOLD_SOURCE = Object.freeze({
  "repository": "https://github.com/sokrypton/localfold",
  "revision": "5ea3d42c911949700401b54003cb28c557fcf2a6",
  "receiptSha256": "ef3d41144a5321536e89561c3f4e5907a6ee5e1581e318133353e76550c381fd",
  "localPatches": [
    {
      "id": "transition-shifted-fast-v1",
      "path": "webgpu/af3/trunk/transition.js",
      "mode": "shifted-fast",
      "activation": "Experimental opt-in for transition generators only; defaults unchanged. Full-model qualification pending.",
      "upstreamSha256": "49c02501cbcd3011745f3863a2e0110f03888c055bfb8a823028c3fe8a566ff4",
      "sha256": "946ae66f36efb0093a9c994975a90708347b4a76542b403c2d67e3aaf984976f",
      "patchSha256": "87cfd32548be290c449f0840ac987881fea1612123492a0d3f1b672d28b51531"
    }
  ]
});
