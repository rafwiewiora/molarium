#!/bin/bash
set -euo pipefail
task_root=$(pwd -P)
previous="$HOME/nfs/molarium-native-cofold-20261112-attempt002"
test -n "${SLURM_JOB_ID:-}"
test -e "$task_root/preflight.complete"
mkdir "$task_root/gpu-started"
date -u +%FT%TZ > "$task_root/gpu-started/started-at.txt"
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-4}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS"
export MKL_NUM_THREADS="$OMP_NUM_THREADS"
export TORCHINDUCTOR_COMPILE_THREADS=1
export WANDB_MODE=disabled
export OPENFOLD_CACHE="$task_root/cache/openfold"
export LD_LIBRARY_PATH="$HOME/miniforge3/envs/openfold3/lib:${LD_LIBRARY_PATH:-}"
job_scratch=$(mktemp -d "${SLURM_TMPDIR:-/tmp}/molarium-cofold-${SLURM_JOB_ID}-XXXXXX")
trap 'rm -rf -- "$job_scratch"' EXIT
cp "$previous/cache/of3-ob-2025-06-30-174k.pt" "$job_scratch/checkpoint.pt"
export TORCH_EXTENSIONS_DIR="$job_scratch/torch-extensions"
export TRITON_CACHE_DIR="$job_scratch/triton"
for group in "$task_root"/groups/group-*; do
  group_name=$(basename "$group")
  srun --ntasks=1 "$previous/environments/openbind0/bin/python" "$task_root/native_run.py" \
    --method openbind0 --protocol torch-standard --inputs "$group/inputs" --output "$task_root/results/$group_name" \
    --checkpoint "$job_scratch/checkpoint.pt" --cache "$task_root/cache/openfold"
done
