#!/bin/bash
set -euo pipefail
task_root=$(pwd -P)
test -n "${SLURM_JOB_ID:-}"
mkdir "$task_root/analysis-started"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK:-2}"
export OMP_NUM_THREADS="$OPENBLAS_NUM_THREADS"
export MPLCONFIGDIR="$task_root/mplconfig"
export LD_LIBRARY_PATH="$HOME/miniforge3/envs/openfold3/lib:${LD_LIBRARY_PATH:-}"
native_python="$HOME/nfs/molarium-native-cofold-20261112-attempt002/environments/openbind0/bin/python"
"$native_python" - <<'PY' "$task_root"
from pathlib import Path
import sys,json,hashlib
r=Path(sys.argv[1]);m=json.loads((r/'source-manifest.json').read_text())
for name,digest in m.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest
PY
cohort_inputs="$HOME/nfs/molarium-native-cofold-20261112-attempt009/inputs"
"$native_python" "$task_root/code/native_cohort.py" assemble --inputs "$cohort_inputs" \
  --attempt "$HOME/nfs/molarium-native-cofold-20261112-attempt009/results/openbind0-torch-standard-attempt001=$cohort_inputs" \
  --attempt "$HOME/nfs/molarium-native-cofold-20261112-attempt011/results/group-000=$HOME/nfs/molarium-native-cofold-20261112-attempt011/groups/group-000/inputs" \
  --attempt "$HOME/nfs/molarium-native-cofold-20261112-attempt012/results/group-000=$HOME/nfs/molarium-native-cofold-20261112-attempt012/groups/group-000/inputs" \
  --allow-interrupted --output "$task_root/assembled-cohort"
"$native_python" "$task_root/code/convert_native.py" --native "$task_root/assembled-cohort" \
  --inputs "$cohort_inputs/comparison.json" --output "$task_root/results/library.json"
"$native_python" "$task_root/code/compare_libraries.py" \
  --library "browser=$task_root/inputs/browser.json" --library "native25=$task_root/inputs/native25.json" \
  --library "standard=$task_root/results/library.json" --pair browser:standard --pair native25:standard \
  --output "$task_root/results/agreement.json"
"$native_python" "$task_root/code/residue_profile.py" --left "$task_root/inputs/browser.json" \
  --right "$task_root/results/library.json" --output "$task_root/results/residue-profile.json"
"$native_python" - <<'PY' "$task_root"
from pathlib import Path
import sys,json,hashlib,time
r=Path(sys.argv[1]);b=json.loads((r/'results/library.json').read_text());assert len(b['poses'])==48
m={'status':'complete','assembledPoses':48,'completedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'files':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (r/'results').rglob('*')if p.is_file()}}
(r/'finalization.complete.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m))
PY
