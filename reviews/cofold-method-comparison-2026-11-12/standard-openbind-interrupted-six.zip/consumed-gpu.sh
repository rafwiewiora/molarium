#!/bin/bash
set -euo pipefail
task_root=$(pwd -P)
previous="$HOME/nfs/molarium-native-cofold-20261112-attempt002"
test -n "${SLURM_JOB_ID:-}"
test -e "$task_root/preflight.complete"
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-4}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS"
export MKL_NUM_THREADS="$OMP_NUM_THREADS"
export TORCHINDUCTOR_COMPILE_THREADS=1
export WANDB_MODE=disabled
export OPENFOLD_CACHE="$task_root/cache/openfold"
export TORCH_EXTENSIONS_DIR="$task_root/cache/torch-extensions-$1"
export TRITON_CACHE_DIR="$task_root/cache/triton-$1"
export LD_LIBRARY_PATH="$HOME/miniforge3/envs/openfold3/lib:${LD_LIBRARY_PATH:-}"
exec srun --ntasks=1 "$previous/environments/openbind0/bin/python" "$task_root/native_run.py" \
 --method openbind0 --protocol "$1" --inputs "$task_root/inputs" --output "$task_root/results/openbind0-$1-attempt001" \
 --checkpoint "$previous/cache/of3-ob-2025-06-30-174k.pt" --cache "$task_root/cache/openfold"
