#!/bin/bash
set -euo pipefail
export OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH="$HOME/miniforge3/envs/openfold3/lib:${LD_LIBRARY_PATH:-}"
"$HOME/nfs/molarium-native-cofold-20261112-attempt002/environments/openbind0/bin/python" preflight.py
