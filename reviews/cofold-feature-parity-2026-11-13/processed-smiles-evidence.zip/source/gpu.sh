#!/bin/bash
set -euo pipefail
task_root=$(pwd -P)
previous="$HOME/nfs/molarium-native-cofold-20261112-attempt002"
test -n "${SLURM_JOB_ID:-}"
case_id=9t51-a1jtm
test -e "$task_root/preflight.complete"

mkdir "$task_root/gpu-started/$case_id"
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-4}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS"
export MKL_NUM_THREADS="$OMP_NUM_THREADS"
export TORCHINDUCTOR_COMPILE_THREADS=1
export WANDB_MODE=disabled
export LD_LIBRARY_PATH="$HOME/miniforge3/envs/openfold3/lib:${LD_LIBRARY_PATH:-}"
export OPENFOLD_CACHE="$task_root/cache/$case_id"
mkdir "$OPENFOLD_CACHE"
srun --ntasks=1 "$previous/environments/openbind0/bin/python" "$task_root/capture_native_features.py" \
 --inputs "$task_root/inputs/$case_id" --output "$task_root/results/$case_id" \
 --browser-library "$task_root/browser-library.json" \
 --reference-receipt "$task_root/references/$case_id.json" \
 --checkpoint "$previous/cache/of3-ob-2025-06-30-174k.pt"
