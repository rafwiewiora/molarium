from pathlib import Path
import hashlib,json,os
from capture_native_features import processed_smiles_query
from native_run import resolved_input_files
root=Path.cwd();assert os.environ.get('SLURM_JOB_ID');(root/'preflight-started').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in json.loads((root/'source-manifest.json').read_bytes()).items():assert sha(root/name)==digest
case='9t51-a1jtm';inputs=root/'inputs'/case
reference=json.loads((root/'references'/(case+'.json')).read_bytes())
spec=json.loads((inputs/'comparison.json').read_bytes())
assert reference['status']=='complete'and reference['method']=='openbind0'
assert {str(p.relative_to(inputs)):sha(p)for p in inputs.rglob('*')if p.is_file()}==reference['inputFiles']
assert sha(inputs/'comparison.json')==reference['inputSha256']
output=root/'preflight-resolved';output.mkdir()
query,_=resolved_input_files(inputs,output,spec)
resolved,control=processed_smiles_query(spec,json.loads((root/'browser-library.json').read_bytes()),json.loads(query.read_bytes()))
(root/'preflight.json').write_text(json.dumps({'status':'complete','jobId':os.environ['SLURM_JOB_ID'],'control':control,'inferenceAllowed':False},indent=2)+'\n')
(root/'preflight.complete').write_text('passed\n');print(json.dumps(control))
