"""Post-job preservation and cancellation of this task's unstartable children."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time,zipfile
p=argparse.ArgumentParser();p.add_argument('plan');p.add_argument('index',type=int);a=p.parse_args()
assert os.environ.get('SLURM_JOB_ID')
plan=json.loads(Path(a.plan).read_bytes());entry=plan['entries'][a.index]
root=Path.home()/'nfs'/entry['root'];output=Path.cwd()/('preserved-'+entry['label']);output.mkdir()
state=subprocess.check_output(['sacct','-X','-j',str(entry['parentJob']),'-n','-P','--format=JobID,State,ExitCode'],text=True).strip()
complete=any(line.split('|')[0]==str(entry['parentJob'])and line.split('|')[1]=='COMPLETED'and line.split('|')[2]=='0:0'for line in state.splitlines())
cancellations=[]
if not complete:
 for child in entry.get('cancelUnstartableChildren',[]):
  child_state=subprocess.check_output(['squeue','-h','-j',str(child),'-o','%T'],text=True).strip()
  if child_state=='PENDING':
   subprocess.run(['scancel',str(child)],check=True);cancellations.append(child)
members={}
def add(path,name):
 if path.is_file():members[name]=path.read_bytes()
manifest=root/'source-manifest.json'
if manifest.exists():
 for name in json.loads(manifest.read_bytes()):
  path=root/name;assert path.resolve().is_relative_to(root.resolve());add(path,'source/'+name)
 add(manifest,'source/source-manifest.json')
for name in ['job-submissions.json','preflight.json','preflight.complete','setup-receipt.json','image-index.json','chrome-release-metadata.json','runtime-gap.txt','cancelled-unstarted-host-runtime-job.txt','gpu-identity.txt','slurm-grant.txt','nvidia-icd.json','chrome-version.txt','bun-version.txt']:
 add(root/name,name)
for folder in ['logs','original-setup-failure']:
 if(root/folder).exists():
  for path in sorted((root/folder).rglob('*')):
   if path.is_file():add(path,str(path.relative_to(root)))
results=root/'results'
if results.exists():
 for path in sorted(results.rglob('*')):
  relative=str(path.relative_to(root))
  if path.is_file()and('/features/'in relative or'/trained-embedder/'in relative or'/resolved-inputs/'in relative or path.name in ['receipt.json','capture-runner.json','processed-smiles-query.json']):add(path,relative)
for path in sorted(root.glob('comparison*')):
 if path.is_file():add(path,path.name)
for previous_name in entry.get('historyRoots',[]):
 previous=Path.home()/'nfs'/previous_name
 for name in ['setup-receipt.json','source-manifest.json','job-submissions.json','chrome-release-metadata.json']:
  add(previous/name,'history/'+previous_name+'/'+name)
 if(previous/'logs').exists():
  for path in sorted((previous/'logs').iterdir()):
   if path.is_file():add(path,'history/'+previous_name+'/logs/'+path.name)
add(Path(__file__),'preservation-script.py')
archive=output/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
raw=archive.read_bytes();sha=lambda data:hashlib.sha256(data).hexdigest()
r={'schema':'molarium.queued-control-preservation.v1','planEntry':entry,'parentSlurmState':state,'cancelledUnstartableChildren':cancellations,'collectorJobId':os.environ['SLURM_JOB_ID'],'capturedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Read-only scientific-output preservation; no inference. Original receipts and failed states remain unchanged.','archive':{'file':'evidence.zip','bytes':len(raw),'sha256':sha(raw),'files':[{'path':n,'bytes':len(data),'sha256':sha(data)}for n,data in sorted(members.items())]}}
(output/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'label':entry['label'],'files':len(members),'archiveBytes':len(raw),'parentState':state,'cancelledChildren':cancellations}))
